// export const urlAssets = "http://localhost:3000/uploads/"
// export const serect = "e84b3b8d-3fc5-4ea8-941e-66e83b3fe449"